head -n1 /proc/stat
g=-
for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/kernel/gpu/gpu_busy /sys/class/misc/mali0/device/utilization /sys/devices/platform/*.mali/utilization; do
  [ -r "$f" ] || continue
  v=$(cat "$f" 2>/dev/null | tr -dc '0-9' | cut -c1-3)
  [ -n "$v" ] && { g=$v; break; }
done
echo "G:$g"
fps=-
L=$(dumpsys SurfaceFlinger --list 2>/dev/null | grep -iE 'freefire' | grep -viE 'background|bounds' | head -n 1)
if [ -n "$L" ]; then
  ts=$(dumpsys SurfaceFlinger --latency "$L" 2>/dev/null | cut -f2 | grep -E '^[0-9]+$' | grep -vE '^0$|^9223372036854775807$')
  if [ -n "$ts" ]; then
    last=$(echo "$ts" | tail -n 1); lim=$((last-1000000000)); c=0
    for t in $ts; do [ "$t" -ge "$lim" ] && c=$((c+1)); done
    fps=$c
  fi
fi
echo "F:$fps"
