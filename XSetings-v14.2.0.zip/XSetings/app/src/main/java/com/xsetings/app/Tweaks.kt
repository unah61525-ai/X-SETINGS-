package com.xsetings.app

import rikka.shizuku.Shizuku

object Sh {
    /** Jalankan perintah shell lewat Shizuku. Return (exitCode, output). */
    fun run(cmd: String): Pair<Int, String> = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "($cmd) 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor() to out.trim()
    } catch (e: Throwable) {
        -1 to (e.cause?.message ?: e.message ?: "error")
    }

    fun detectHz(): Int {
        val out = run("dumpsys display").second
        val hz = Regex("fps=([0-9]+(?:\\.[0-9]+)?)").findAll(out)
            .mapNotNull { it.groupValues[1].toDoubleOrNull() }.maxOrNull()?.toInt() ?: 60
        return hz.coerceIn(60, 165)
    }
}

class Feature(val name: String, val desc: String, val cmds: (Int) -> List<String>)

val FF = listOf("com.dts.freefireth", "com.dts.freefiremax")
const val RESO = "850x1900"

fun lockHz(hz: Int) = listOf(
    "settings put system peak_refresh_rate $hz",
    "settings put system min_refresh_rate $hz",
    "settings put system user_refresh_rate $hz",
    "settings put secure refresh_rate_mode 2"
)

val features = listOf(
    Feature("DETEKSI HP", "Auto deteksi HZ asli HP lu") {
        listOf("getprop ro.product.model", "dumpsys display | grep -m1 fps=")
    },
    Feature("LOCK HZ DISPLAY", "Lock 90/120 HZ biar ga patah-patah") { hz -> lockHz(hz) },
    Feature("LOCK FPS TRUE LOCK", "Lock FPS biar ga di limit") { hz ->
        listOf(
            "setprop debug.sf.frame_rate_multiple_threshold $hz",
            "setprop debug.graphics.game_default_frame_rate_disabled true",
            "settings put global game_default_frame_rate_disabled 1"
        )
    },
    Feature("MATIIN PENGHEMAT BATRE", "Batre saver OFF total") {
        listOf("settings put global low_power 0", "settings put global low_power_trigger_level 0")
    },
    Feature("VULKAN ON", "Grafik enteng, FF anti framedrop") {
        listOf("setprop debug.hwui.renderer skiavk", "setprop debug.renderengine.backend skiavkthreaded")
    },
    Feature("TOUCH PAS", "Pointer, slop, drag biar HS nyantol") {
        listOf(
            "settings put system pointer_speed 7",
            "settings put secure long_press_timeout 250",
            "settings put secure multi_press_timeout 250"
        )
    },
    Feature("PING GAMING STABIL", "DNS + wifi suspend OFF biar ping stabil") {
        listOf(
            "settings put global private_dns_mode hostname",
            "settings put global private_dns_specifier dns.google",
            "settings put global wifi_suspend_optimizations_enabled 0",
            "settings put global wifi_sleep_policy 2"
        )
    },
    Feature("ANIMASI PAS 0.5x", "Buka tas ganti senjata sat set") {
        listOf(
            "settings put global window_animation_scale 0.5",
            "settings put global transition_animation_scale 0.5",
            "settings put global animator_duration_scale 0.5"
        )
    },
    Feature("BOOST GPU MAX POWER", "GPU gas poll") {
        listOf("setprop debug.egl.hw 1", "setprop debug.performance.tuning 1", "setprop debug.composition.type gpu")
    },
    Feature("BOOST CPU MAX POWER", "CPU performance mode") {
        listOf("cmd power set-fixed-performance-mode-enabled true", "cmd power set-mode 0")
    },
    Feature("BOOSTING FREE FIRE MAX", "Whitelist FF + standby bucket") {
        FF.flatMap { listOf("am set-standby-bucket $it active", "cmd appops set $it RUN_ANY_IN_BACKGROUND allow") }
    },
    Feature("GAME MODE ON", "Mode game aktif") {
        FF.map { "cmd game mode performance $it" }
    },
    Feature("COOLING SYSTEM", "Anti panas, suhu turun") {
        listOf(
            "settings put global wifi_scan_always_enabled 0",
            "settings put global ble_scan_always_enabled 0"
        )
    },
    Feature("LOG BUFFER BERSIH & MATI", "Log dibersihin, RAM lega") {
        listOf("logcat -b all -c", "logcat -G 64K")
    },
    Feature("RAM BOOST", "Bunuh app sampah, FF prioritas") {
        listOf("am kill-all")
    },
    Feature("BACKGROUND LIMIT 5 APP", "Background ke limit") {
        listOf("settings put global activity_manager_constants max_cached_processes=5")
    },
    Feature("ANTI NOTIF PAS MAIN", "Notif heads up OFF, fokus war") {
        listOf("settings put global heads_up_notifications_enabled 0")
    },
    Feature("WHITELIST FF", "FF ga di sleep device idle") {
        FF.map { "cmd deviceidle whitelist +$it" }
    },
    Feature("DISABLE THERMAL THROTTLE", "Thermal matiin, gas terus") {
        listOf("cmd thermalservice override-status 0", "setprop debug.thermal.throttle.disable 1")
    },
    Feature("DISABLE ADAPTIVE BATRE", "Adaptive batre OFF") {
        listOf(
            "settings put global adaptive_battery_management_enabled 0",
            "settings put global app_auto_restriction_enabled false"
        )
    },
    Feature("SURFACEFLINGER TUNE", "Layar lebih halus") {
        listOf("setprop debug.sf.latch_unsignaled 1", "setprop debug.sf.disable_backpressure 1")
    },
    Feature("IO & VM TUNE", "Swappiness + dirty ratio halus (butuh root)") {
        listOf(
            "echo 20 > /proc/sys/vm/swappiness",
            "echo 10 > /proc/sys/vm/dirty_ratio",
            "echo 5 > /proc/sys/vm/dirty_background_ratio"
        )
    },
    Feature("NETWORK STABIL", "TCP buffer + mobile data always on") {
        listOf(
            "settings put global mobile_data_always_on 1",
            "settings put global tcp_default_init_rwnd 60"
        )
    },
    Feature("AUDIO GAME MODE", "Audio jernih, musuh kedenger") {
        listOf("settings put system sound_effects_enabled 0")
    },
    Feature("FINAL LOCK LC1 + ESY DRAG 10%", "Kunci ulang HZ + FPS, reso $RESO") { hz ->
        lockHz(hz) + listOf("wm size $RESO")
    }
)

val resetCmds = listOf(
    "wm size reset",
    "settings put global window_animation_scale 1.0",
    "settings put global transition_animation_scale 1.0",
    "settings put global animator_duration_scale 1.0",
    "cmd thermalservice reset",
    "cmd power set-fixed-performance-mode-enabled false"
)
