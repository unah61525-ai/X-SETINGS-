package com.xsetings.app

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.*
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private val KEY = "gungtzy"          // key aktivasi
    private val ACCENT = Color.parseColor("#00E5FF")
    private val prefs by lazy { getSharedPreferences("xs", MODE_PRIVATE) }
    private lateinit var root: LinearLayout
    private val rows = mutableListOf<TextView>()
    private var running = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun devId() = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
    private fun licensed() = prefs.getString("dev", null) == devId() && prefs.getBoolean("ok", false)

    private fun shizukuReady() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val sv = ScrollView(this).apply { setBackgroundColor(Color.parseColor("#0B0B12")) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(44), dp(16), dp(24))
        }
        sv.addView(root)
        setContentView(sv)
        try {
            Shizuku.addRequestPermissionResultListener { _, _ -> runOnUiThread { render() } }
            Shizuku.addBinderReceivedListenerSticky { runOnUiThread { render() } }
            Shizuku.addBinderDeadListener { runOnUiThread { render() } }
        } catch (_: Throwable) {}
        render()
    }

    private fun tv(t: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = t; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.BLACK); isAllCaps = false
        background = GradientDrawable().apply { setColor(ACCENT); cornerRadius = dp(10).toFloat() }
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
    }

    private fun render() {
        root.removeAllViews(); rows.clear()
        root.addView(tv("X-SETINGS", 34f, ACCENT, true).apply { gravity = Gravity.CENTER })
        root.addView(tv("V14.1.3  •  25 FITUR [AKTIF SEMUA]", 13f, Color.parseColor("#9AA0B4"))
            .apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(16)) })

        // Shizuku
        val ready = shizukuReady()
        val binder = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
        root.addView(tv(
            when {
                ready -> "● Shizuku: AKTIF & IZIN DIBERIKAN"
                binder -> "● Shizuku: jalan, izin belum diberikan"
                else -> "● Shizuku: BELUM JALAN (buka app Shizuku → Start)"
            }, 14f, if (ready) Color.parseColor("#00E676") else Color.parseColor("#FF5252"), true))
        if (!ready) root.addView(btn("Beri Izin Shizuku") {
            if (!binder) {
                Toast.makeText(this, "Start Shizuku dulu (Wireless debugging / root)", Toast.LENGTH_LONG).show()
                packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")?.let { startActivity(it) }
            } else try { Shizuku.requestPermission(100) } catch (e: Throwable) {
                Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
            }
        })

        if (!licensed()) { renderKey(); return }

        root.addView(tv("🔑 Key aktif (terkunci ke device ini)", 12f, Color.parseColor("#9AA0B4"))
            .apply { setPadding(0, dp(8), 0, 0) })
        val go = btn("⚡ AKTIFKAN 25 FITUR") { if (!running) applyAll() }
        root.addView(go)
        root.addView(btn("Reset (reso, animasi, thermal)") {
            Thread {
                resetCmds.forEach { Sh.run(it) }
                runOnUiThread { Toast.makeText(this, "Reset selesai", Toast.LENGTH_SHORT).show() }
            }.start()
        }.apply { (background as GradientDrawable).setColor(Color.parseColor("#3A3F55")); setTextColor(Color.WHITE) })

        root.addView(btn("📊 Monitor Melayang: TAMPILKAN") { startMonitor() })
        root.addView(btn("Matikan Monitor Melayang") {
            startService(Intent(this, OverlayService::class.java).setAction("STOP"))
        }.apply { (background as GradientDrawable).setColor(Color.parseColor("#3A3F55")); setTextColor(Color.WHITE) })

        features.forEachIndexed { i, f ->
            val t = tv("⬜ %02d  %s\n      %s".format(i + 1, f.name, f.desc), 13f, Color.parseColor("#D0D4E4"))
            t.setPadding(dp(12), dp(10), dp(12), dp(10))
            t.background = GradientDrawable().apply { setColor(Color.parseColor("#151522")); cornerRadius = dp(8).toFloat() }
            t.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            rows.add(t); root.addView(t)
        }
    }

    private fun renderKey() {
        root.addView(tv("Masukkan key (1 key = 1 device)", 14f).apply { setPadding(0, dp(20), 0, dp(6)) })
        val et = EditText(this).apply {
            hint = "KEY"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT; setSingleLine()
        }
        root.addView(et)
        root.addView(btn("AKTIFKAN KEY") {
            val bound = prefs.getString("dev", null)
            when {
                et.text.toString().trim() != KEY -> toast("Key salah")
                bound != null && bound != devId() -> toast("Key sudah terpakai di device lain")
                else -> {
                    prefs.edit().putString("dev", devId()).putBoolean("ok", true).apply()
                    toast("Key aktif"); render()
                }
            }
        })
        root.addView(tv("ID device: ${devId()}", 11f, Color.parseColor("#9AA0B4")).apply { setPadding(0, dp(10), 0, 0) })
    }

    private fun startMonitor() {
        if (!Settings.canDrawOverlays(this)) {
            toast("Izinkan 'Tampil di atas aplikasi lain' untuk X-SETINGS")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
        toast("Monitor aktif. Tahan tombol merah untuk menutup")
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun applyAll() {
        if (!shizukuReady()) { toast("Aktifkan & beri izin Shizuku dulu"); return }
        running = true
        Thread {
            val hz = Sh.detectHz()
            features.forEachIndexed { i, f ->
                val codes = f.cmds(hz).map { Sh.run(it).first }
                val ok = codes.count { it == 0 }
                val mark = when { ok == codes.size -> "✅"; ok > 0 -> "🟡"; else -> "⚠️" }
                val extra = if (i == 0) "  [${hz} HZ]" else ""
                runOnUiThread {
                    rows.getOrNull(i)?.text = "$mark %02d  %s%s  (%d/%d)\n      %s"
                        .format(i + 1, f.name, extra, ok, codes.size, f.desc)
                }
            }
            running = false
            runOnUiThread { toast("Selesai. ⚠️ = tidak didukung di HP/ROM ini") }
        }.start()
    }
}
