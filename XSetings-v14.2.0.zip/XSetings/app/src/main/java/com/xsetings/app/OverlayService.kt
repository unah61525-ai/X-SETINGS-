package com.xsetings.app

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.view.*
import android.widget.*

/** Monitor performa melayang: CPU, GPU, RAM, baterai, suhu, FPS, jam. */
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private val ui = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var bg: Handler? = null
    @Volatile private var alive = false
    private var prevTot = 0L
    private var prevIdle = 0L
    @Volatile private var cpu = "--"
    @Volatile private var gpu = "--"
    @Volatile private var fps = "--"
    private val tv = HashMap<String, TextView>()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        if (root != null) return START_STICKY
        startForeground(7, notif())
        buildBar()
        alive = true
        worker = HandlerThread("xs-mon").also { it.start() }
        bg = Handler(worker!!.looper)
        bg!!.post(poll)
        ui.post(refresh)
        return START_STICKY
    }

    private fun notif(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("mon", "Monitor", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, "mon")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("X-SETINGS monitor aktif")
            .setContentText("Ketuk Matikan untuk menutup")
            .addAction(Notification.Action.Builder(0, "Matikan", stop).build())
            .setOngoing(true).build()
    }

    private fun item(key: String, label: String, color: Int = Color.WHITE): TextView {
        val t = TextView(this).apply {
            textSize = 11f; setTextColor(color); setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(5), 0, dp(5), 0); text = "$label --"
        }
        tv[key] = t; return t
    }

    private fun buildBar() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(5), dp(5))
            background = GradientDrawable().apply { setColor(Color.argb(205, 120, 124, 132)); cornerRadius = dp(10).toFloat() }
        }
        listOf(
            Triple("cpu", "CPU", Color.WHITE), Triple("gpu", "GPU", Color.WHITE), Triple("ram", "RAM", Color.WHITE),
            Triple("bat", "BAT", Color.WHITE), Triple("tmp", "TMP", Color.WHITE),
            Triple("fps", "FPS", Color.parseColor("#00E5FF")), Triple("clk", "", Color.WHITE)
        ).forEach { (k, l, c) -> bar.addView(item(k, l, c)) }
        val handle = TextView(this).apply {
            text = "✥"; textSize = 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(Color.parseColor("#C0666B")); cornerRadius = dp(8).toFloat() }
            layoutParams = LinearLayout.LayoutParams(dp(30), dp(30)).apply { leftMargin = dp(6) }
            setOnLongClickListener { stopSelf(); true }
        }
        bar.addView(handle)
        root = bar

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(28) }

        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0
        bar.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; false }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt()
                    wm.updateViewLayout(bar, lp); true
                }
                else -> false
            }
        }
        wm.addView(bar, lp)
    }

    // ---- baca CPU/GPU/FPS lewat Shizuku di thread terpisah ----
    private val poll = object : Runnable {
        override fun run() {
            if (!alive) return
            try {
                val script = assets.open("mon.sh").bufferedReader().readText()
                val out = Sh.run(script)
                if (out.first == 0 || out.second.isNotEmpty()) parse(out.second)
            } catch (_: Throwable) {}
            bg?.postDelayed(this, 1500)
        }
    }

    private fun parse(o: String) {
        for (line in o.lines()) {
            when {
                line.startsWith("cpu ") -> {
                    val n = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                    if (n.size >= 8) {
                        val tot = n.take(8).sum(); val idle = n[3] + n[4]
                        if (prevTot > 0 && tot > prevTot) cpu = ((tot - prevTot - (idle - prevIdle)) * 100 / (tot - prevTot)).toString()
                        prevTot = tot; prevIdle = idle
                    }
                }
                line.startsWith("G:") -> gpu = line.substring(2).trim().ifEmpty { "-" }
                line.startsWith("F:") -> fps = line.substring(2).trim().ifEmpty { "-" }
            }
        }
    }

    private fun v(s: String, unit: String = " %") = if (s == "-" || s == "--" || s.isEmpty()) "--" else s + unit

    private val refresh = object : Runnable {
        override fun run() {
            if (!alive) return
            try {
                val mi = ActivityManager.MemoryInfo()
                getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
                val ram = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toString()
                val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val lvl = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val tmp = (b?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1) / 10.0
                val c = java.util.Calendar.getInstance()
                tv["cpu"]?.text = "CPU " + v(cpu)
                tv["gpu"]?.text = "GPU " + v(gpu)
                tv["ram"]?.text = "RAM " + v(ram)
                tv["bat"]?.text = "BAT " + (if (lvl >= 0) "$lvl %" else "--")
                tv["tmp"]?.text = "TMP " + (if (tmp > 0) "%.0f °C".format(tmp) else "--")
                tv["fps"]?.text = "FPS " + v(fps, "")
                tv["clk"]?.text = "%02d:%02d:%02d".format(c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), c.get(java.util.Calendar.SECOND))
            } catch (_: Throwable) {}
            ui.postDelayed(this, 1000)
        }
    }

    override fun onDestroy() {
        alive = false
        ui.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        try { root?.let { wm.removeView(it) } } catch (_: Throwable) {}
        root = null
        super.onDestroy()
    }
}
